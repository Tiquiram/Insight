package com.example.fragment_example.CalendarFiles;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fragment_example.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Calendar_View extends LinearLayout {
    ImageButton nextButton,previousButton;
    TextView currentDate;
    GridView gridView;
    private static final int MAX_CALENDAR_DAYS =42;
    Calendar calendar =Calendar.getInstance(Locale.ENGLISH);
    Context context;
    SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy",Locale.ENGLISH);
    SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM",Locale.ENGLISH);
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy",Locale.ENGLISH);
    SimpleDateFormat eventDateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.ENGLISH);

    EventGrid_Adapter eventGrid_adapter;
    AlertDialog alertDialog;
    List<Date> dates = new ArrayList<Date>();
    List<Event> eventsList = new ArrayList<Event>();
    DB_OpenHelper dbOpenHelper;

    public Calendar_View(Context context) {
        super(context);
    }

    public Calendar_View(final Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        InitializeLayout();
        SetUpCalendar();
        previousButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH,-1);
                SetUpCalendar();
            }
        });
        nextButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH,1);
                SetUpCalendar();
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(true);
                final View addView = LayoutInflater.from(parent.getContext()).inflate(R.layout.calendar_add_event_layout,null);
                final EditText EventName = addView.findViewById(R.id.eventNameTxt);
                final TextView EventTime = addView.findViewById(R.id.eventTimeTxt);
                ImageButton setTime = addView.findViewById(R.id.setTimeBtn);
                Button addEvent = addView.findViewById(R.id.addEventBtn);
                setTime.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        int hours = calendar.get(Calendar.HOUR_OF_DAY);
                        int minutes = calendar.get(Calendar.MINUTE);
                        TimePickerDialog timePickerDialog =  new TimePickerDialog(addView.getContext(), R.style.Theme_AppCompat_Dialog, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                Calendar c = Calendar.getInstance();
                                c.set(Calendar.HOUR_OF_DAY,hourOfDay);
                                c.set(Calendar.MINUTE,minute);
                                c.setTimeZone(TimeZone.getDefault());
                                SimpleDateFormat hformat = new SimpleDateFormat("K:mm a",Locale.ENGLISH);
                                String event_Time = hformat.format(c.getTime());
                                EventTime.setText(event_Time);
                            }
                        },hours,minutes,false);
                        timePickerDialog.show();
                    }
                });
                final String date = eventDateFormat.format(dates.get(position));
                final String month =monthFormat.format(dates.get(position));
                final String year = yearFormat.format(dates.get(position));
                addEvent.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SaveEvent(EventName.getText().toString(),EventTime.getText().toString(),date,month,year);
                        SetUpCalendar();
                        alertDialog.dismiss();
                    }
                });
                builder.setView(addView);
                alertDialog=builder.create();
                alertDialog.show();
            }
        });

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String date = eventDateFormat.format(dates.get(position));

                AlertDialog.Builder builder =  new AlertDialog.Builder(context);
                builder.setCancelable(true);
                View showView = LayoutInflater.from(parent.getContext()).inflate(R.layout.calendar_recyclerview_layout,null);
                RecyclerView recyclerView = showView.findViewById(R.id.event_recycler_view);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(showView.getContext());
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setHasFixedSize(true);
                EventRecycler_Adapter eventsRecyclerAdapter = new EventRecycler_Adapter(showView.getContext(),CollectEventByDate(date));
                recyclerView.setAdapter(eventsRecyclerAdapter);
                eventsRecyclerAdapter.notifyDataSetChanged();

                builder.setView(showView);
                alertDialog = builder.create();
                alertDialog.show();
                alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        SetUpCalendar();

                    }
                });

                return true;
            }
        });

    }
    private ArrayList<Event> CollectEventByDate(String date){
        ArrayList<Event> arrayList = new ArrayList<>();
        dbOpenHelper = new DB_OpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadEvents(date,database);
        while(cursor.moveToNext()){
            String event = cursor.getString(cursor.getColumnIndex(DB_Structure.EVENT));
            String time = cursor.getString(cursor.getColumnIndex(DB_Structure.TIME));
            String date_ = cursor.getString(cursor.getColumnIndex(DB_Structure.DATE));
            String month = cursor.getString(cursor.getColumnIndex(DB_Structure.MONTH));
            String year = cursor.getString(cursor.getColumnIndex(DB_Structure.YEAR));
            Event events =  new Event(event,time,date_,month,year);
            arrayList.add(events);
        }
        cursor.close();
        dbOpenHelper.close();

        return arrayList;
    }

    public Calendar_View(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
    private void SaveEvent(String event,String time,String date, String month,String year){
        dbOpenHelper =  new DB_OpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.SaveEvent(event,time,date,month,year,database);
        dbOpenHelper.close();
        Toast.makeText(context,"Event Saved",Toast.LENGTH_SHORT).show();
    }
    private void InitializeLayout(){
        LayoutInflater inflater =(LayoutInflater)context.getSystemService((Context.LAYOUT_INFLATER_SERVICE));
        View view = inflater.inflate(R.layout.calendar_layout,this);
        nextButton = view.findViewById(R.id.nextBtn);
        previousButton=view.findViewById(R.id.previousBtn);
        currentDate = view.findViewById(R.id.currDateTxt);
        gridView =view.findViewById(R.id.calendar_grid);
    }
    private void SetUpCalendar(){
        String currDate = dateFormat.format(calendar.getTime());
        currentDate.setText(currDate);
        dates.clear();
        Calendar monthCalendar = (Calendar)calendar.clone();
        monthCalendar.set(Calendar.DAY_OF_MONTH,1);
        int FirstDayofMonth= monthCalendar.get(Calendar.DAY_OF_WEEK)-1;
        monthCalendar.add(Calendar.DAY_OF_MONTH,-FirstDayofMonth);
        CollectEventsPerMonth(monthFormat.format(calendar.getTime()),yearFormat.format(calendar.getTime()));
        while(dates.size() < MAX_CALENDAR_DAYS){
            dates.add(monthCalendar.getTime());
            monthCalendar.add(Calendar.DAY_OF_MONTH,1);
        }
        eventGrid_adapter = new EventGrid_Adapter(context,dates,calendar,eventsList);
        gridView.setAdapter(eventGrid_adapter);
    }

    private void CollectEventsPerMonth(String Month,String Year){
        eventsList.clear();
        dbOpenHelper = new DB_OpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadEventsPerMonth(Month,Year,database);
        while(cursor.moveToNext()){
            String event = cursor.getString(cursor.getColumnIndex(DB_Structure.EVENT));
            String time = cursor.getString(cursor.getColumnIndex(DB_Structure.TIME));
            String date = cursor.getString(cursor.getColumnIndex(DB_Structure.DATE));
            String month = cursor.getString(cursor.getColumnIndex(DB_Structure.MONTH));
            String year = cursor.getString(cursor.getColumnIndex(DB_Structure.YEAR));
            Event events =  new Event(event,time,date,month,year);
            eventsList.add(events);
        }
        cursor.close();
        dbOpenHelper.close();
    }
}

