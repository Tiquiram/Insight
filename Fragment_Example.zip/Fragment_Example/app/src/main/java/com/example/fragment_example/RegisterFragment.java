package com.example.fragment_example;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fragment_example.model.RegisterLoginResponse;
import com.example.fragment_example.model.User;
import com.example.fragment_example.viewmodels.LoginViewModel;
import com.example.fragment_example.viewmodels.RegisterViewModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterFragment extends Fragment {

    RegisterLoginResponse loginResponse;
    RegisterViewModel userViewModel;

    public RegisterFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        userViewModel = ViewModelProviders.of(this).get(RegisterViewModel.class);
        userViewModel.init("jwest6", "justinewest6@gmail.com", "1234");
        userViewModel.getUserRepository().observe(this, response -> {
            if(response != null) {
                loginResponse = new RegisterLoginResponse(response.getUser(), response.getToken());
                Log.d("register response", loginResponse.getUser().getUserName());
            }
        });
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false);
    }
}