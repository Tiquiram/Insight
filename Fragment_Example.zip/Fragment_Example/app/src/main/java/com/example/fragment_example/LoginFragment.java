package com.example.fragment_example;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fragment_example.model.RegisterLoginResponse;
import com.example.fragment_example.model.User;
import com.example.fragment_example.viewmodels.LoginViewModel;
import com.example.fragment_example.viewmodels.UserViewModel;

import java.util.ArrayList;
import java.util.List;


public class LoginFragment extends Fragment {

    RegisterLoginResponse loginResponse;
    LoginViewModel userViewModel;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        userViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        userViewModel.init("jwest6", "1234");
        userViewModel.getUserRepository().observe(this, response -> {
            if(response != null) {
                loginResponse = new RegisterLoginResponse(response.getUser(), response.getToken());
                Log.d("login response", loginResponse.getUser().getUserName());
            }
        });

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

}