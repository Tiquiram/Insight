package com.example.fragment_example.CalendarFiles;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DB_OpenHelper extends SQLiteOpenHelper {

    private static final String CREATE_EVENTS_TABLE = "create table " + DB_Structure.EVENT_TABLE_NAME+" (ID INTEGER PRIMARY KEY AUTOINCREMENT, "+
            DB_Structure.EVENT+" TEXT, "+DB_Structure.TIME+ " TEXT, "+DB_Structure.DATE+" TEXT, "+
            DB_Structure.MONTH+" TEXT," + DB_Structure.YEAR+" TEXT)";
    private static final String DROP_EVENTS_TABLE = "DROP TABLE IF EXISTS "+DB_Structure.EVENT_TABLE_NAME;

    public DB_OpenHelper(@Nullable Context context){
        super(context,DB_Structure.DB_NAME,null,DB_Structure.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_EVENTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_EVENTS_TABLE);
        onCreate(db);
    }

    public void SaveEvent(String event,String time,String date,String month,String year, SQLiteDatabase database) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DB_Structure.EVENT, event);
        contentValues.put(DB_Structure.TIME, time);
        contentValues.put(DB_Structure.DATE, date);
        contentValues.put(DB_Structure.MONTH, month);
        contentValues.put(DB_Structure.YEAR, year);
        database.insert(DB_Structure.EVENT_TABLE_NAME, null, contentValues);
    }
    public Cursor ReadEvents(String date, SQLiteDatabase database){
        String [] projections = {DB_Structure.EVENT,DB_Structure.TIME,DB_Structure.DATE,DB_Structure.MONTH,DB_Structure.YEAR};
        String selection = DB_Structure.DATE+"=?";
        String [] selectionArgs ={date};
        return database.query(DB_Structure.EVENT_TABLE_NAME,projections,selection,selectionArgs,null,null,null);
    }
    public Cursor ReadEventsPerMonth(String month,String year,SQLiteDatabase database){
        String [] projections = {DB_Structure.EVENT,DB_Structure.TIME,DB_Structure.DATE,DB_Structure.MONTH,DB_Structure.YEAR};
        String selection = DB_Structure.MONTH+"=? and "+DB_Structure.YEAR+"=?";
        String [] selectionArgs ={month,year};
        return database.query(DB_Structure.EVENT_TABLE_NAME,projections,selection,selectionArgs,null,null,null);
    }
    public void deleteEvent(String event,String date,String time,SQLiteDatabase database){
        String selection = DB_Structure.EVENT + "=? and "+DB_Structure.DATE+"=? and "+DB_Structure.TIME+"=?";
        String[] selectionArg = {event,date,time};
        database.delete(DB_Structure.EVENT_TABLE_NAME,selection,selectionArg);
    }
}
