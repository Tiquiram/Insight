package com.example.fragment_example.CalendarFiles;

public class Event{
    String event;
    String time;
    String date;
    String month;
    String year;

    public Event(String event, String time, String date, String month, String year) {
        this.event = event;
        this.time = time;
        this.date = date;
        this.month = month;
        this.year = year;
    }

    public String getEvent() {
        return event;
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }

    public String getMonth() {
        return month;
    }

    public String getYear() {
        return year;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
