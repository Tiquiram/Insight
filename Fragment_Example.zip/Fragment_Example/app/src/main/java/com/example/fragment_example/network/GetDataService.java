package com.example.fragment_example.network;

import com.example.fragment_example.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface GetDataService {

    @GET("/api/accounts/users/")
    Call<List<User>> getAllUsers();

}
