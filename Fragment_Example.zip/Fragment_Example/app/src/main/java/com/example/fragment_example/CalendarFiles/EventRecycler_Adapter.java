package com.example.fragment_example.CalendarFiles;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fragment_example.R;

import java.util.ArrayList;

public class EventRecycler_Adapter extends RecyclerView.Adapter<EventRecycler_Adapter.MyViewHolder> {

    Context context;
    ArrayList<Event> arrayList;
    DB_OpenHelper dbOpenHelper;

    public EventRecycler_Adapter(Context context, ArrayList<Event> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.calendar_view_event_layout,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final Event events = arrayList.get(position);
        holder.Event.setText(events.getEvent());
        holder.Datetxt.setText(events.getDate());
        holder.Time.setText(events.getTime());
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteCalendarEvent(events.getEvent(),events.getDate(),events.getTime());
                arrayList.remove(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView Datetxt,Event,Time;
        Button deleteButton;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Datetxt = itemView.findViewById(R.id.eventDateTxt);
            Event= itemView.findViewById(R.id.eventNameTxt);
            Time= itemView.findViewById(R.id.eventTimeTxt);
            deleteButton=itemView.findViewById(R.id.deleteButton);

        }
    }

    private void deleteCalendarEvent(String event,String date,String time){
        dbOpenHelper= new DB_OpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.deleteEvent(event,date,time,database);
        dbOpenHelper.close();
    }
}

